<?php

namespace App\Http\Controllers;

use App\CustomProductVariable;
use Illuminate\Http\Request;

class CustomProductVariableController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CustomProductVariable  $customProductVariable
     * @return \Illuminate\Http\Response
     */
    public function show(CustomProductVariable $customProductVariable)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CustomProductVariable  $customProductVariable
     * @return \Illuminate\Http\Response
     */
    public function edit(CustomProductVariable $customProductVariable)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CustomProductVariable  $customProductVariable
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CustomProductVariable $customProductVariable)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CustomProductVariable  $customProductVariable
     * @return \Illuminate\Http\Response
     */
    public function destroy(CustomProductVariable $customProductVariable)
    {
        //
    }
}
