<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LanguageTranslation extends Model
{
    //
}
